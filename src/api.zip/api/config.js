var config = {
	
	base_url:	'https://api.danjiguanjia.com',
	test_url:	'https://api.danji.jianong.com',
	web_url:	'https://m.danjiguanjia.com'
}

export default config